## wisata v2
Nama : Riski Dafa Setyawan <br />
Kelas : IK-2C <br />
NIM : 3.34.21.2.21

<img src="https://user-images.githubusercontent.com/94169174/211987417-4c227595-1d96-41aa-82b8-d40821361911.png" width="500" />
<img src="https://user-images.githubusercontent.com/94169174/211987435-c7fed4aa-7a36-4a60-980d-fa59938477f4.png" width="500" />
